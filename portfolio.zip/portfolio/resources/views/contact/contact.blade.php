<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Section</title>
    
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .table-responsive {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Contact Section</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Contact</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Main Content Container -->
    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0">Records</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="recordsTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Bg Title</th>
                                <th>Note</th>
                                <th>Second Title</th>
                                <th>Add Detail</th>
                                <th>Thired Title</th>
                                <th>Contact Num</th>
                                <th>Fourth Title</th>
                                <th>Email</th>
                                <th>Fifth Title</th>
                                <th>Resume Link</th>
                                <th>Linked In</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($contacts as $contact)
                            <tr>
                                <td>{{ $contact->id }}</td>
                                <td>{{ $contact->title}}</td>
                                <td>{{ $contact->bg_title}}</td>
                                <td>{{ $contact->note }}</td>
                                <td>{{ $contact->second_title }}</td>
                                <td>{{ $contact->add_detail }}</td>
                                <td>{{ $contact->thired_title }}</td>
                                <td>{{ $contact->contact_num }}</td>
                                <td>{{ $contact->fourth_title }}</td>
                                <td>{{ $contact->email }}</td>
                                <td>{{ $contact->fifth_title }}</td>
                                <td>{{ $contact->resume_link }}</td>
                                <td>{{ $contact->linked_in }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#recordsTable').DataTable(); 
    });
    </script>
</body>
</html>
