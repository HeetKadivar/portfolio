<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Section</title>
    
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .table-responsive {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Resume Section</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Resume</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Main Content Container -->
    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0">Records</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="resumessTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>paragraph</th>
                                <th>second_title</th>
                                <th>project1</th>
                                <th>project2</th>
                                <th>project3</th>
                                <th>project4</th>
                                <th>project5</th>
                                <th>project6</th>
                                <th>thired_title</th>
                                <th>skill1</th>
                                <th>skill2</th>
                                <th>skill3</th>
                                <th>skill4</th>
                                <th>skill5</th>
                                <th>skill6</th>
                                <th>skill7</th>
                                <th>skill8</th>
                                <th>skill9</th>
                                <th>skill10</th>
                                <th>fourth_title</th>
                                <th>ssc</th>
                                <th>hsc</th>
                                <th>college</th>
                                <th>fifth_title</th>
                                <th>lang_1</th>
                                <th>lang_2</th>
                                <th>lang_3</th>
                                <th>six_title</th>
                                <th>name</th>
                                <th>email</th>
                                <th>location</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($resumes as $resume)
                            <tr>
                                <td>{{ $resume->id }}</td>
                                <td>{{ $resume->title}}</td>
                                <td>{{ $resume->paragraph }}</td>
                                <td>{{ $resume->second_title }}</td>
                                <td>{{ $resume->project1 }}</td>
                                <td>{{ $resume->project2 }}</td>
                                <td>{{ $resume->project3 }}</td>
                                <td>{{ $resume->project4 }}</td>
                                <td>{{ $resume->project5 }}</td>
                                <td>{{ $resume->project6 }}</td>
                                <td>{{ $resume->thired_title }}</td>
                                <td>{{ $resume->skill1 }}</td>
                                <td>{{ $resume->skill2 }}</td>
                                <td>{{ $resume->skill3 }}</td>
                                <td>{{ $resume->skill4 }}</td>
                                <td>{{ $resume->skill5 }}</td>
                                <td>{{ $resume->skill6 }}</td>
                                <td>{{ $resume->skill7 }}</td>
                                <td>{{ $resume->skill8 }}</td>
                                <td>{{ $resume->skill9 }}</td>
                                <td>{{ $resume->skill10 }}</td>
                                <td>{{$resume->fourth_title}}</td>
                                <td>{{$resume->ssc}}</td>
                                <td>{{$resume->hsc}}</td>
                                <td>{{$resume->college}}</td>
                                <td>{{$resume->fifth_title}}</td>
                                <td>{{$resume->lang_1}}</td>
                                <td>{{$resume->lang_2}}</td>
                                <td>{{$resume->lang_3}}</td>
                                <td>{{$resume->six_title}}</td>
                                <td>{{$resume->name}}</td>
                                <td>{{$resume->email}}</td>
                                <td>{{$resume->location}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Include jQuery, Bootstrap, and DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#resumessTable').DataTable(); // Initialize DataTable
    });
    </script>
</body>
</html>
