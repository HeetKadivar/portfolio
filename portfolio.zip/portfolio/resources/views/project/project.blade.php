<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Section</title>
    
    <!-- Include Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Include DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .table-responsive {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Project Section</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Project</a>
                </li>
                <!-- Add more navigation items as needed -->
            </ul>
        </div>
    </nav>

    <!-- Main Content Container -->
    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0">Records</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="recordsTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>title</th>
                                <th>sub_title</th>
                                <th>note</th>
                                <th>project1_img</th>
                                <th>project1_name</th>
                                <th>project1_description</th>
                                <th>project2_img</th>
                                <th>project2_name</th>
                                <th>project2_description</th>
                                <th>project3_img</th>
                                <th>project3_name</th>
                                <th>project3_description</th>
                                <th>project4_img</th>
                                <th>project4_name</th>
                                <th>project4_description</th>
                                <th>project5_img</th>
                                <th>project5_name</th>
                                <th>project5_description</th>
                                <th>bg_img</th>
                                <th>info</th>
                                <th>sub_info</th>
                                <th>github</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($projects as $project)
                            <tr>
                                <td>{{ $project->id }}</td>
                                <td>{{ $project->title }}</td>
                                <td>{{ $project->sub_title }}</td>
                                <td>{{ $project->note }}</td>
                                <td><img src="{{ asset('theme/images/' . $project->project1_img) }}" alt="Image" class="img-thumbnail" width="50"></td>
                                <td>{{ $project->project1_name }}</td>
                                <td>{{ $project->project1_description }}</td>
                                <td><img src="{{ asset('theme/images/' . $project->project2_img) }}" alt="Image" class="img-thumbnail" width="50"></td>
                                <td>{{ $project->project2_name }}</td>
                                <td>{{ $project->project2_description }}</td>
                                <td><img src="{{ asset('theme/images/' . $project->project3_img) }}" alt="Image" class="img-thumbnail" width="50"></td>
                                <td>{{ $project->project3_name }}</td>
                                <td>{{ $project->project3_description }}</td>
                                <td><img src="{{ asset('theme/images/' . $project->project4_img) }}" alt="Image" class="img-thumbnail" width="50"></td>
                                <td>{{ $project->project4_name }}</td>
                                <td>{{ $project->project4_description }}</td>
                                <td><img src="{{ asset('theme/images/' . $project->project5_img) }}" alt="Image" class="img-thumbnail" width="50"></td>
                                <td>{{ $project->project5_name }}</td>
                                <td>{{ $project->project5_description }}</td>
                                <td><img src="{{ asset('theme/images/' . $project->bg_img) }}" alt="Image" class="img-thumbnail" width="50"></td>
                                <td>{{ $project->info }}</td>
                                <td>{{ $project->sub_info }}</td>
                                <td><a href="{{ $project->github }}" target="_blank">{{ $project->github }}</a></td>

                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Include jQuery, Bootstrap, and DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#recordsTable').DataTable(); // Initialize DataTable
    });
    </script>
</body>
</html>
