<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Section</title>
    
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .table-responsive {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">About Section</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">About</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Main Content Container -->
    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0">Records</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="recordsTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Title_Of_Section</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Role</th>
                                <th>Experience</th>
                                <th>Address</th>
                                <th>Bg_name</th>
                                <th>Paragraph</th>
                                <th>Profile</th>
                                <th>Education</th>
                                <th>Language</th>
                                <th>Programming_lang</th>
                                <th>Interest</th>
                                <th>Project_completed</th>
                                <th>Linked_in</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($records as $record)
                            <tr>
                                <td>{{ $record->id }}</td>
                                <td>{{ $record->title_of_section}}</td>
                                <td><img src="{{ asset('theme/images/' . $record->image) }}" alt="Image" class="img-thumbnail" width="50"></td>                                
                                <td>{{ $record->name }}</td>
                                <td>{{ $record->role }}</td>
                                <td>{{ $record->experience }}</td>
                                <td>{{ $record->address }}</td>
                                <td>{{ $record->bg_name }}</td>
                                <td>{{ $record->paragraph }}</td>
                                <td>{{ $record->profile }}</td>
                                <td>{{ $record->education }}</td>
                                <td>{{ $record->language }}</td>
                                <td>{{ $record->programming_lang }}</td>
                                <td>{{ $record->interest }}</td>
                                <td>{{ $record->project_completed }}</td>
                                <td><a href="{{ $record->linked_in }}" target="_blank">{{ $record->linked_in }}</a></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Include jQuery, Bootstrap, and DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#recordsTable').DataTable(); // Initialize DataTable
    });
    </script>
</body>
</html>
