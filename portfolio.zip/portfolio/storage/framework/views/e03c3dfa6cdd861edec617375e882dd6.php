<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Section</title>
    
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .table-responsive {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Resume Section</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Resume</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Main Content Container -->
    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0">Records</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="resumessTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>paragraph</th>
                                <th>second_title</th>
                                <th>project1</th>
                                <th>project2</th>
                                <th>project3</th>
                                <th>project4</th>
                                <th>project5</th>
                                <th>project6</th>
                                <th>thired_title</th>
                                <th>skill1</th>
                                <th>skill2</th>
                                <th>skill3</th>
                                <th>skill4</th>
                                <th>skill5</th>
                                <th>skill6</th>
                                <th>skill7</th>
                                <th>skill8</th>
                                <th>skill9</th>
                                <th>skill10</th>
                                <th>fourth_title</th>
                                <th>ssc</th>
                                <th>hsc</th>
                                <th>college</th>
                                <th>fifth_title</th>
                                <th>lang_1</th>
                                <th>lang_2</th>
                                <th>lang_3</th>
                                <th>six_title</th>
                                <th>name</th>
                                <th>email</th>
                                <th>location</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $resumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resume->id); ?></td>
                                <td><?php echo e($resume->title); ?></td>
                                <td><?php echo e($resume->paragraph); ?></td>
                                <td><?php echo e($resume->second_title); ?></td>
                                <td><?php echo e($resume->project1); ?></td>
                                <td><?php echo e($resume->project2); ?></td>
                                <td><?php echo e($resume->project3); ?></td>
                                <td><?php echo e($resume->project4); ?></td>
                                <td><?php echo e($resume->project5); ?></td>
                                <td><?php echo e($resume->project6); ?></td>
                                <td><?php echo e($resume->thired_title); ?></td>
                                <td><?php echo e($resume->skill1); ?></td>
                                <td><?php echo e($resume->skill2); ?></td>
                                <td><?php echo e($resume->skill3); ?></td>
                                <td><?php echo e($resume->skill4); ?></td>
                                <td><?php echo e($resume->skill5); ?></td>
                                <td><?php echo e($resume->skill6); ?></td>
                                <td><?php echo e($resume->skill7); ?></td>
                                <td><?php echo e($resume->skill8); ?></td>
                                <td><?php echo e($resume->skill9); ?></td>
                                <td><?php echo e($resume->skill10); ?></td>
                                <td><?php echo e($resume->fourth_title); ?></td>
                                <td><?php echo e($resume->ssc); ?></td>
                                <td><?php echo e($resume->hsc); ?></td>
                                <td><?php echo e($resume->college); ?></td>
                                <td><?php echo e($resume->fifth_title); ?></td>
                                <td><?php echo e($resume->lang_1); ?></td>
                                <td><?php echo e($resume->lang_2); ?></td>
                                <td><?php echo e($resume->lang_3); ?></td>
                                <td><?php echo e($resume->six_title); ?></td>
                                <td><?php echo e($resume->name); ?></td>
                                <td><?php echo e($resume->email); ?></td>
                                <td><?php echo e($resume->location); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Include jQuery, Bootstrap, and DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#resumessTable').DataTable(); // Initialize DataTable
    });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\heet's_portfolio\portfolio\resources\views/resume/resume.blade.php ENDPATH**/ ?>