<!DOCTYPE html>
<html lang="en">

<head>
	<title>Heet Kadivar Portfolio</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">

	<link rel="stylesheet" href="<?php echo e(asset('theme/css/open-iconic-bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('theme/css/animate.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('theme/css/owl.carousel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('theme/css/owl.theme.default.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('theme/magnific-popup.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('theme/css/aos.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('theme/css/ionicons.min.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('theme/css/flaticon.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('theme/css/icomoon.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('theme/css/style.css')); ?>">



	<style>
		/*======================================
//--//-->   ABOUT
======================================*/

		.about-mf .box-shadow-full {
			padding-top: 4rem;
			padding-bottom: 4rem;
		}

		.about-mf .about-img {
			margin-bottom: 2rem;
		}

		.about-mf .about-img img {
			margin-left: 10px;
		}


		.skill-mf .progress {
			/* background-color: #cde1f8; */
			margin: .5rem 0 1.2rem 0;
			border-radius: 0;
			height: .7rem;
		}

		.skill-mf .progress .progress-bar {
			height: .7rem;
			background-color: #ffbd39;
		}


		/* Animation styles */
		#typing-animation {
			position: relative;
			font-size: 30px;
			font-weight: bold;
			color: rgb(255, 255, 255);
			overflow: hidden;
			white-space: nowrap;
			animation: typing 3s steps(20, end) infinite;
		}

		#typing-animation:before {
			content: "";
			/* position: absolute; */
			top: 0;
			left: 0;
			width: 0;
			height: 100%;
			background-color: #ccc;
			animation: typing-cursor 0.5s ease-in-out infinite;
		}

		@keyframes typing {
			from {
				width: 0;
			}

			to {
				width: 100%;
			}
		}

		@keyframes typing-cursor {
			from {
				width: 5px;
			}

			to {
				width: 0;
			}
		}


		/* project image zoom effect */

		.zoom-effect {
			overflow: hidden;
			transition: transform 0.3s ease-out;
		}

		.zoom-effect:hover {
			transform: scale(1.1);
		}
	</style>


</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

	<!-- Home Section Started -->
	<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar ftco-navbar-light site-navbar-target" id="ftco-navbar">
			<div class="container">
				<a class="navbar-brand" href="#"><?php echo e($record->first_name); ?></a>
				<button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse"
					data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
					<span class="oi oi-menu"></span> Menu
				</button>

				<div class="collapse navbar-collapse" id="ftco-nav">
					<ul class="navbar-nav nav ml-auto">
						<li class="nav-item"><a href="#home-section" class="nav-link"><span>Home</span></a></li>
						<li class="nav-item"><a href="#about-section" class="nav-link"><span>About</span></a></li>
						<li class="nav-item"><a href="#resume-section" class="nav-link"><span>Resume</span></a></li>
						<li class="nav-item"><a href="#project-section" class="nav-link"><span>Projects</span></a></li>
						<li class="nav-item"><a href="#contact-section" class="nav-link"><span>Contact</span></a></li>
					</ul>
				</div>
			</div>
		</nav>



		<section id="home-section" class="hero">
			<div class="home-slider  owl-carousel">
				<div class="slider-item ">
					<div class="overlay"></div>
					<div class="container">
						<div class="row d-md-flex no-gutters slider-text align-items-end justify-content-end"
							data-scrollax-parent="true">
							<div class="one-third js-fullheight order-md-last img"
								style="background-image: url('<?php echo e(asset('theme/images/' . $record->images)); ?>');">
								<div class="overlay"></div>
							</div>

							<div class="one-forth d-flex  align-items-center ftco-animate"
								data-scrollax=" properties: { translateY: '70%' }">
								<div class="text">
									<span class="subheading"><?php echo e($record->sub_heading); ?></span>
									<h1 class="mb-4 mt-3">I'm <span><?php echo e($record->second_name); ?></span></h1>

									<span id="typing-animation"></span>

									<script>

										const typingAnimationElement = document.getElementById('typing-animation');

										const typingTexts = [
											'<?php echo e($record->profession); ?> ',

										];

										function playTypingAnimation(text) {
											for (let i = 0; i < text.length; i++) {
												setTimeout(() => {
													typingAnimationElement.textContent += text[i];
												}, i * 200);
											}

											setTimeout(() => {
												typingAnimationElement.textContent = '';
												playTypingAnimation(typingTexts[(typingTexts.indexOf(text) + 1) % typingTexts.length]);
											}, text.length * 200);
										}

										playTypingAnimation(typingTexts[0]);

									</script>

									<br>
									<br>

									<p><a href="<?php echo e($record->first_github_link); ?>" class="btn btn-primary py-3 px-4">Github</a>
										<a href="<?php echo e($record->first_github_link); ?>"
											class="btn btn-white btn-outline-white py-3 px-4">My works</a>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<!-- Home Section End -->

	<!-- About Section Started -->
<section class="ftco-about img ftco-section ftco-no-pb" id="about-section">
	<?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-6 col-lg-5 d-flex">
					<div class="img-about img d-flex align-items-stretch">
						<div class="overlay">
							<div class="row">
								<div class="col-6 col-sm-5">
									<div class="about-img">
										<img src="<?php echo e(asset('theme/images/' . $about->image)); ?>"
											class="img-fluid rounded b-shadow-a" alt="">
									</div>
								</div>
								<!-- Details next to profile image -->
								<div class="col-6 col-sm-7">
									<div class="about-info">
										<p><span class="title-s">Name: </span> <span><?php echo e($about->name); ?></span></p>
										<p><span class="title-s">Role: </span> <span><?php echo e($about->role); ?></span></p>
										<p><span class="title-s">Experience: </span> <span><?php echo e($about->experience); ?></span></p>
										<p><span class="title-s">Address: </span> <span><?php echo e($about->address); ?></span></p>
									</div>
								</div>
							</div>

							<div class="skill-mf mt-4">
								<p class="title-s">Skills</p>
								<?php
									$skills = ['SQL' => 85, 'PHP' => 85, 'MySQL' => 90, 'CI4' => 80, 'Laravel' => 70, 'Cyber' => 45];
								?>

								<?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill => $percentage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<span><?php echo e($skill); ?></span> <span class="pull-right"><?php echo e($percentage); ?>%</span>
									<div class="progress">
										<div class="progress-bar" role="progressbar" style="width: <?php echo e($percentage); ?>%;" aria-valuenow="<?php echo e($percentage); ?>" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-6 col-lg-7 pl-lg-5 pb-5">
					<div class="row justify-content-start pb-3">
						<div class="col-md-12 heading-section ftco-animate">
							<h1 class="big"><?php echo e($about->bg_name); ?></h1>
							<h2 class="mb-4"><?php echo e($about->title_of_section); ?></h2>
							<p><?php echo e($about->paragraph); ?></p>

							<ul class="about-info mt-4 px-md-0 px-2">
								<li class="d-flex"><span>Profile:</span> <span><?php echo e($about->profile); ?></span></li>
								<li class="d-flex"><span>Education:</span> <span><?php echo e($about->education); ?></span></li>
								<li class="d-flex"><span>Language:</span> <span><?php echo e($about->language); ?></span></li>
								<li class="d-flex"><span>Programming Languages:</span> <span><?php echo e($about->programming_lang); ?></span></li>
								<li class="d-flex"><span>Interest:</span> <span><?php echo e($about->interest); ?></span></li>
							</ul>
						</div>
					</div>

					<div class="counter-wrap ftco-animate d-flex mt-md-3">
						<div class="text">
							<p class="mb-4">
								<span class="number" data-number="10">0</span> <span>+</span>
								<span>&nbsp; <?php echo e($about->project_completed); ?></span>
							</p>
							<p><a href="<?php echo e($about->linked_in); ?>" class="btn btn-primary py-3 px-3">LinkedIn</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>


	<!-- About Section End -->


	<section class="ftco-section ftco-no-pb" id="resume-section">
		<?php $__currentLoopData = $resumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div class="container">
				<div class="row justify-content-center"> <!-- Add justify-content-center here -->
					<div class="col-md-6">
						<div class="resume-wrap ftco-animate mx-auto"> <!-- Add mx-auto here -->
							<h2 class="mb-4"><?php echo e($resume->title); ?></h2>
							<p><?php echo e($resume->paragraph); ?></p>

							<h3 class="mb-3"><?php echo e($resume->second_title); ?></h3>
							<p><?php echo e($resume->project1); ?></p>
							<p><?php echo e($resume->project2); ?></p>
							<p><?php echo e($resume->project3); ?></p>
							<p><?php echo e($resume->project4); ?></p>
							<p><?php echo e($resume->project5); ?></p>
							<p><?php echo e($resume->project6); ?></p>

							<h3 class="mb-3"><?php echo e($resume->thired_title); ?></h3>
							<p><?php echo e($resume->skill1); ?></p>
							<p><?php echo e($resume->skill2); ?></p>
							<p><?php echo e($resume->skill3); ?></p>
							<p><?php echo e($resume->skill4); ?></p>
							<p><?php echo e($resume->skill5); ?></p>
							<p><?php echo e($resume->skill6); ?></p>
							<p><?php echo e($resume->skill7); ?></p>
							<p><?php echo e($resume->skill8); ?></p>
							<p><?php echo e($resume->skill9); ?></p>
							<p><?php echo e($resume->skill10); ?></p>

							<h3 class="mb-3"><?php echo e($resume->fourth_title); ?></h3>
							<p><?php echo e($resume->ssc); ?></p>
							<p><?php echo e($resume->hsc); ?></p>
							<p><?php echo e($resume->college); ?></p>

							<h3 class="mb-3"><?php echo e($resume->fifth_title); ?></h3>
							<p><?php echo e($resume->lang_1); ?></p>
							<p><?php echo e($resume->lang_2); ?></p>
							<p><?php echo e($resume->lang_3); ?></p>

							<h3 class="mb-3"><?php echo e($resume->six_title); ?></h3>
							<p><?php echo e($resume->name); ?></p>
							<p>Email: <a href="mailto:<?php echo e($resume->email); ?>"><?php echo e($resume->email); ?></a></p>
							<p>Location: <?php echo e($resume->location); ?></p>
						</div>
					</div>
				</div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<br>
			<!-- Education Section Started -->
			<?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="row">
						<h1 class="big-4"><?php echo e($education->title); ?></h1>
						<div class="underline"></div>
					</div>
					<br>

					<div class="row justify-content-center"> <!-- Add justify-content-center here -->
						<div class="col-md-6">
							<div class="resume-wrap ftco-animate mx-auto"> <!-- Add mx-auto here -->
								<span class="date"><?php echo e($education->year_of_passing); ?></span>
								<h2><?php echo e($education->course); ?></h2>
								<span class="position"><?php echo e($education->college_name); ?></span>
								<p class="mt-4">Grade: <?php echo e($education->grade); ?></p>
							</div>
						</div>
					</div>



					<div class="row justify-content-center mt-5">
						<div class="col-md-6 text-center ftco-animate">
							<p><a href="#" class="btn btn-primary py-4 px-5">Download CV</a></p>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</section>
	<!-- Education Section Ended -->

	<!-- Project Section started -->
	<section class="ftco-section" id="project-section">
		<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


				<div class="container">
					<div class="row justify-content-center mb-5 pb-5">
						<div class="col-md-7 heading-section text-center ftco-animate">
							<h1 class="big big-2"><?php echo e($project->title); ?></h1>
							<h2 class="mb-4"><?php echo e($project->sub_title); ?></h2>
							<p><?php echo e($project->note); ?></p>
						</div>
					</div>
					<div class="row d-flex">
						<!-- Project 1 -->
						<div class="col-md-4 d-flex ftco-animate">
							<div class="blog-entry justify-content-end">
								<a href="#" class="block-20 zoom-effect" style="background-image: url('<?php echo e(asset('theme/images/' . $project->project1_img)); ?>'); 
						background-size: contain; 
						background-position: center; 
						background-repeat: no-repeat; 
						height: 250px;">
								</a>
								<div class="text mt-3 float-right d-block">
									<h3 class="heading"><a href="#"><?php echo e($project->project1_name); ?></a></h3>
									<p><?php echo e($project->project1_description); ?></p>
								</div>
							</div>
						</div>

						<!-- Project 2 -->
						<div class="col-md-4 d-flex ftco-animate">
							<div class="blog-entry justify-content-end">
								<a href="#" class="block-20 zoom-effect" style="background-image: url('<?php echo e(asset('theme/images/' . $project->project2_img)); ?>'); 
						background-size: contain; 
						background-position: center; 
						background-repeat: no-repeat; 
						height: 250px;">
								</a>
								<div class="text mt-3 float-right d-block">
									<h3 class="heading"><a href="#"><?php echo e($project->project2_name); ?></a></h3>
									<p><?php echo e($project->project2_description); ?></p>
								</div>
							</div>
						</div>

						<!-- Project 3 -->
						<div class="col-md-4 d-flex ftco-animate">
							<div class="blog-entry">
								<a href="#" class="block-20 zoom-effect" style="background-image: url('<?php echo e(asset('theme/images/' . $project->project3_img)); ?>'); 
						background-size: contain; 
						background-position: center; 
						background-repeat: no-repeat; 
						height: 250px;">
								</a>
								<div class="text mt-3 float-right d-block">
									<h3 class="heading"><a href="#"><?php echo e($project->project3_name); ?></a></h3>
									<p><?php echo e($project->project3_description); ?></p>
								</div>
							</div>
						</div>
					</div>
					<br>

					<!-- Centered Projects 4 and 5 -->
					<div class="row d-flex justify-content-center">
						<!-- Project 4 -->
						<div class="col-md-4 d-flex ftco-animate">
							<div class="blog-entry justify-content-end">
								<a href="#" class="block-20 zoom-effect" style="background-image: url('<?php echo e(asset('theme/images/' . $project->project4_img)); ?>'); 
						background-size: contain; 
						background-position: center; 
						background-repeat: no-repeat; 
						height: 250px;">
								</a>
								<div class="text mt-3 float-right d-block">
									<h3 class="heading"><a href="#"><?php echo e($project->project4_name); ?></a></h3>
									<p><?php echo e($project->project4_description); ?></p>
								</div>
							</div>
						</div>

						<!-- Project 5 -->
						<div class="col-md-4 d-flex ftco-animate">
							<div class="blog-entry justify-content-end">
								<a href="#" class="block-20 zoom-effect" style="background-image: url('<?php echo e(asset('theme/images/' . $project->project5_img)); ?>'); 
						background-size: contain; 
						background-position: center; 
						background-repeat: no-repeat; 
						height: 250px;">
								</a>
								<div class="text mt-3 float-right d-block">
									<h3 class="heading"><a href="#"><?php echo e($project->project5_name); ?></a></h3>
									<p><?php echo e($project->project5_description); ?></p>
								</div>
							</div>
						</div>
					</div>

				</div>
				</div>
			</section>

			<section class="ftco-section ftco-no-pt ftco-no-pb ftco-counter img" id="section-counter">

				<div class="ftco-section ftco-hireme img margin-top"
					style="background-image: url('<?php echo e(asset('theme/images/' . $project->bg_img)); ?>');">
					<div class="row justify-content-center">
						<div class="col-md-7 ftco-animate text-center">
							<h2><?php echo e($project->info); ?><span> <?php echo e($project->sub_info); ?> </span> </h2>
							<div class="heading">
								<br>
								<p><a href="<?php echo e($project->github); ?>" class="btn btn-primary py-3 px-5">GitHub</a></p>
							</div>
						</div>
					</div>
				</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</section>

	<!-- Project Section Ended -->

	<section class="ftco-section contact-section ftco-no-pb" id="contact-section">
		<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


			<div class="container">
				<div class="row justify-content-center mb-5 pb-3">
					<div class="col-md-7 heading-section text-center ftco-animate">
						<h1 class="big big-2"><?php echo e($contact->title); ?></h1>
						<h2 class="mb-4"><?php echo e($contact->bg_title); ?></h2>
						<p><?php echo e($contact->note); ?></p>
					</div>
				</div>

				<div class="row d-flex contact-info mb-5">
					<div class="col-md-6 col-lg-3 d-flex ftco-animate">
						<div class="align-self-stretch box p-4 text-center">
							<div class="icon d-flex align-items-center justify-content-center">
								<span class="icon-map-signs"></span>
							</div>
							<h3 class="mb-4"><?php echo e($contact->second_title); ?></h3>
							<p><?php echo e($contact->add_detail); ?></p>
						</div>
					</div>
					<div class="col-md-6 col-lg-3 d-flex ftco-animate">
						<div class="align-self-stretch box p-4 text-center">
							<div class="icon d-flex align-items-center justify-content-center">
								<span class="icon-phone2"></span>
							</div>
							<h3 class="mb-4"><?php echo e($contact->thired_title); ?></h3>
							<p><a href="tel://0101010101"><?php echo e($contact->contact_num); ?></a></p>
						</div>
					</div>
					<div class="col-md-6 col-lg-3 d-flex ftco-animate">
						<div class="align-self-stretch box p-4 text-center">
							<div class="icon d-flex align-items-center justify-content-center">
								<span class="icon-paper-plane"></span>
							</div>
							<h3 class="mb-4"><?php echo e($contact->fourth_title); ?></h3>
							<p><a href="mailto:heetkadivar212@gmail.com"><?php echo e($contact->email); ?></a></p>
						</div>
					</div>
					<div class="col-md-6 col-lg-3 d-flex ftco-animate">
						<div class="align-self-stretch box p-4 text-center">
							<div class="icon d-flex align-items-center justify-content-center">
								<span class="icon-globe"></span>
							</div>
							<h3 class="mb-4"><?php echo e($contact->fifth_title); ?></h3>
							<p><a href="#"><?php echo e($contact->resume_link); ?></a></p>
						</div>
					</div>

					<div class="container">
						<br>
						<br>
						<div class="row justify-content-center">
							<div class="col-md-7 ftco-animate text-center">
								<h2>Have a<span> Question? </span> <a href="#"
										class="btn btn-primary py-3 px-5">Click Here</a> </h2>
							</div>
						</div>
						<br>
						<ul class="ftco-footer-social list-unstyled d-flex justify-content-center align-items-center mb-0">
							<li class="ftco-animate normal-txt">Find me on </li>
							<li class="ftco-animate"><a href="<?php echo e($contact->linked_in); ?>"><span
										class="icon-linkedin"></span></a></li>
						</ul>
						<br>
					</div>
				</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</section>




	<footer class="ftco-footer ftco-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">

					<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						Copyright &copy;
						<script>document.write(new Date().getFullYear());</script> All rights reserved | This template
						is made with <i class="icon-heart color-danger" aria-hidden="true"></i> by <a
							href="https://colorlib.com" target="_blank">Colorlib</a>
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
					</p>
				</div>
			</div>
		</div>
	</footer>


	<!-- loader -->
	<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
			<circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
			<circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
				stroke="#F96D00" />
		</svg></div>


	<script src="<?php echo e(asset('theme/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/jquery.easing.1.3.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/jquery.waypoints.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/jquery.stellar.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/jquery.magnific-popup.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/aos.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/jquery.animateNumber.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/scrollax.min.js')); ?>"></script>

	<script src="<?php echo e(asset('theme/js/main.js')); ?>"></script>


</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\heet's_portfolio\portfolio\resources\views/heet.blade.php ENDPATH**/ ?>