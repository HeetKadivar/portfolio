<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Section</title>
    
    <!-- Include Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Include DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .table-responsive {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Home Section</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home</a>
                </li>
                <!-- Add more navigation items as needed -->
            </ul>
        </div>
    </nav>

    <!-- Main Content Container -->
    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0">Records</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="recordsTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Sub Heading</th>
                                <th>Second Name</th>
                                <th>Profession</th>
                                <th>First GitHub Link</th>
                                <th>Second GitHub Link</th>
                                <th>Images</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($record->id); ?></td>
                                <td><?php echo e($record->first_name); ?></td>
                                <td><?php echo e($record->sub_heading); ?></td>
                                <td><?php echo e($record->second_name); ?></td>
                                <td><?php echo e($record->profession); ?></td>
                                <td><a href="<?php echo e($record->first_github_link); ?>" target="_blank"><?php echo e($record->first_github_link); ?></a></td>
                                <td><a href="<?php echo e($record->second_github_link); ?>" target="_blank"><?php echo e($record->second_github_link); ?></a></td>
                                <td><img src="<?php echo e(asset('theme/images/' . $record->images)); ?>" alt="Image" class="img-thumbnail" width="50"></td>
                                <td><?php echo e($record->created_at); ?></td>
                                <td><?php echo e($record->updated_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Include jQuery, Bootstrap, and DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#recordsTable').DataTable(); // Initialize DataTable
    });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\heet's_portfolio\portfolio\resources\views/HomeSection/homerecords.blade.php ENDPATH**/ ?>