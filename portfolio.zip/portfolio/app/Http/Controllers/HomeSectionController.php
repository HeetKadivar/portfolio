<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;


class HomeSectionController extends Controller
{
    public function index()
    {
        $records = DB::table('homesection')->select([
            'id',
            'first_name',
            'sub_heading',
            'second_name',
            'profession',
            'first_github_link',
            'second_github_link',
            'images',
            'created_at',
            'updated_at'
        ])->get();

        return view('HomeSection.homerecords', compact('records'));
    }

    public function about()
    {
        $abouts = DB::table('about')->select([
            'id',
            'title_of_section',
            'image',
            'name',
            'role',
            'experience',
            'address',
            'bg_name',
            'paragraph',
            'profile',
            'education',
            'language',
            'programming_lang',
            'interest',
            'project_completed',
            'linked_in'
        ])->get();

        return view('about.about',compact('abouts'));
    }

    public function resume()
    {
        $resumes = DB::table('resume')->select([
            'id',
            'title',
            'paragraph',
            'second_title',
            'project1',
            'project2',
            'project3',
            'project4',
            'project5',
            'project6',
            'thired_title',
            'skill1',
            'skill2',
            'skill3',
            'skill4',
            'skill5',
            'skill6',
            'skill7',
            'skill8',
            'skill9',
            'skill10',
            'fourth_title',
            'ssc',
            'hsc',
            'college',
            'fifth_title',
            'lang_1',
            'lang_2',
            'lang_3',
            'six_title',
            'name',
            'email',
            'location',
        ])->get();

        return view('resume.resume',compact('resumes'));
    }

    public function education()
    {
        $educations = DB::table('education')->select([
            'id',
            'title',
            'year_of_passing',
            'course',
            'college_name',
            'grade',
        ])->get();

        return view('education.education',compact('educations'));
    }

    public function contact(){

        $contacts = DB::table('contact')->select([
            'id',
            'title',
            'bg_title',
            'note',
            'second_title',
            'add_detail',
            'thired_title',
            'contact_num',
            'fourth_title',
            'email',
            'fifth_title',
            'resume_link',
            'linked_in'
        ])->get();

        return view('contact.contact',compact('contacts'));
    }

    public function project()
    {
        $projects = DB::table('projects')->select([
            'id',
            'title',
            'sub_title',
            'note',
            'project1_img',
            'project1_name',
            'project1_description',
            'project2_img',
            'project2_name',
            'project2_description',
            'project3_img',
            'project3_name',
            'project3_description',
            'project4_img',
            'project4_name',
            'project4_description',
            'project5_img',
            'project5_name',
            'project5_description',
            'bg_img',
            'info',
            'sub_info',
            'github',
        ])->get();

        return view('project.project',compact('projects'));
    }

}
